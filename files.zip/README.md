# Img2Prompt — AI Image to Prompt Generator

> Free AI-powered image to prompt generator. Convert any image to detailed AI prompts for Midjourney, Stable Diffusion, DALL-E, and more.

![Img2Prompt](https://img.shields.io/badge/Powered%20by-LLaVA%20AI-red)
![Cloudflare Workers](https://img.shields.io/badge/Hosted%20on-Cloudflare%20Workers-orange)
![License](https://img.shields.io/badge/License-MIT-green)

---

## 🚀 Features

- 🖼 **Image to Prompt** — Upload any image and get detailed AI descriptions
- ✨ **Text to Image** — Generate images from text (Pro)
- 📦 **Batch Processing** — Analyze multiple images at once (Pro)
- ⚡ **API Access** — REST API for developers (Business)
- 🌍 **Translate Prompt** — 50+ languages (coming soon)
- 🎬 **Video Prompt** — For Sora, Runway, etc. (coming soon)

---

## 💰 Pricing

| Plan | Price | Images/day |
|------|-------|------------|
| Free | $0 | 5 |
| Pro | $9/mo | 100 |
| Business | $29/mo | Unlimited |

---

## 🛠 Tech Stack

- **AI Model:** LLaVA 1.5 7B (`@cf/llava-hf/llava-1.5-7b-hf`)
- **Hosting:** Cloudflare Workers
- **Frontend:** Vanilla HTML/CSS/JS (no framework)

---

## ⚙️ Deploy Your Own

### 1. Clone the repo
```bash
git clone https://github.com/YOUR_USERNAME/img2prompt.git
cd img2prompt
```

### 2. Install Wrangler
```bash
npm install -g wrangler
wrangler login
```

### 3. Deploy
```bash
wrangler deploy
```

### 4. Add AI Binding
- Go to Cloudflare Dashboard → Workers → img2prompt → Settings → Bindings
- Add Workers AI binding with variable name `AI`

---

## 📁 Project Structure

```
img2prompt/
├── worker.js        # Main Cloudflare Worker (contains full SaaS app)
├── wrangler.toml    # Cloudflare config
└── README.md        # This file
```

---

## 📄 License

MIT License — feel free to use, modify, and distribute.

---

Built with ❤️ using [Cloudflare Workers AI](https://developers.cloudflare.com/workers-ai/)
